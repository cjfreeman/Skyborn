
******************************************************
*                    TEMPLATE FAQ                    *
******************************************************

Q. 	What are the gray "FILL" areas in the blanket png?

A. 	Instead of using icon UV offsets to hide visible
	seams on edges at the foot of the bed, I decided
	to make it naturally blend using an existing part
	of the image.  If you don't fill these areas,
	seams will be visible at the foot of the bed.
	
------------------------------------------------------

Q.	What does the text mean on the 64x templates?

A.	The text indicates on which side of the drawn block
	the texture will appear.