package deathcounter.core;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;

import net.minecraft.command.CommandHandler;
import net.minecraft.command.ICommandManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.Configuration;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.Property;
import net.minecraftforge.event.ForgeSubscribe;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.Mod.PreInit;
import cpw.mods.fml.common.Mod.ServerStarted;
import cpw.mods.fml.common.Mod.ServerStarting;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartedEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.relauncher.Side;

/**
 * DeathCounter (Simple)
 *    -for Silvey
 * 
 * Main Mod class
 * 
 * @author iChun
 *
 */

@Mod(modid = "DeathCounter", name="DeathCounter",
		version = "2.0.0"
			)
public class DeathCounter 
{

	public static final String version = "2.0.0";
	public static File saveDir;
	
	public static HashMap<String, Integer> deathCounter = new HashMap<String, Integer>();
	
	public static ArrayList<String> ranking = new ArrayList<String>();
	
	public static int message;
	public static int leaderboardCount;
	public static int outputToTextFile;
	public static int singleSession;
	
	@Instance("DeathCounter")
	public static DeathCounter instance;
	
	@EventHandler
	public void preLoad(FMLPreInitializationEvent event)
	{
		LoggerHelper.init();
		
		Configuration config = new Configuration(event.getSuggestedConfigurationFile());
		config.load();
		
		message = this.addCommentAndReturnInt(config, "deathcounter", "message", "Death Count Messages?\n0 = Disable\n1 = Short message\n2 = Long message", 2);
		leaderboardCount = this.addCommentAndReturnInt(config, "deathcounter", "leaderboardCount", "Number of names to show in the leaderboards", 5);
		singleSession = this.addCommentAndReturnInt(config, "deathcounter", "singleSession", "Do not save deaths in save folder?\n0 = No\n1 = Yes", 0);
		outputToTextFile = this.addCommentAndReturnInt(config, "deathcounter", "outputToTextFile", "Output deaths to text file in save folder?\n(This is overridden to 0 by the singleSession config)\n0 = No\n1 = Yes", 1);

		config.save();
	}
	
	@EventHandler
	public void load(FMLInitializationEvent event)
	{
		MinecraftForge.EVENT_BUS.register(instance);
	}
	
	@EventHandler
	public void serverStarting(FMLServerStartingEvent event)
	{
		ICommandManager manager = event.getServer().getCommandManager();
		if(manager instanceof CommandHandler)
		{
			CommandHandler handler = (CommandHandler)manager;
			handler.registerCommand(new CommandDeathCounter());
		}
	}
	
	@EventHandler
	public void serverStarted(FMLServerStartedEvent event)
	{
		deathCounter.clear();
		ranking.clear();
		
		loadDeaths(DimensionManager.getWorld(0));
		sortRanking();
	}
	
	public int addCommentAndReturnInt(Configuration config, String cat, String s, String comment, int i)
	{
		Property prop = config.get(cat, s, i);
		if(!comment.equalsIgnoreCase(""))
		{
			prop.comment = comment;
		}
		return prop.getInt();
	}
	
	
	public void loadDeaths(WorldServer world)
	{
		File dir = new File(world.getChunkSaveLocation(), "deathCounter");
		if(!dir.exists())
		{
			dir.mkdirs();
		}
		saveDir = dir;
		File[] files = dir.listFiles();
		for(File file : files)
		{
			if(file.getName().endsWith(".dat"))
			{
				String user = file.getName().substring(0, file.getName().length() - 4);
				try
				{
					NBTTagCompound tag = CompressedStreamTools.readCompressed(new FileInputStream(file));
					deathCounter.put(user, tag.getInteger("deaths"));
				}
				catch(EOFException e)
				{
					console("File for " + user + " is corrupted. Flushing.");
				}
				catch(IOException e)
				{
					console("Failed to read file for " + user + ". Flushing.");
				}
			}
		}
	}
	
	public void sortRanking()
	{
		for(Map.Entry<String, Integer> e : deathCounter.entrySet())
		{
			ranking.remove(e.getKey());
			if(e.getValue() > 0)
			{
				for(int i = 0; i < ranking.size(); i++)
				{
					if(getDeathCount(ranking.get(i)) <= e.getValue())
					{
						ranking.add(i, e.getKey());
						break;
					}
				}
				if(!ranking.contains(e.getKey()))
				{
					ranking.add(e.getKey());
				}
			}
		}
		if(singleSession != 1 && outputToTextFile == 1)
		{
			Properties s = new Properties();
			File text = new File(saveDir, "deaths.txt");
			
			if(text == null || text.isDirectory())
			{
				return;
			}

			for(Map.Entry<String, Integer> e : deathCounter.entrySet())
			{
				s.setProperty(e.getKey(), Integer.toString(e.getValue()));
			}
			
			try
			{
				if(!text.exists())
					text.createNewFile();
				FileOutputStream fos = new FileOutputStream(text);
				s.store(((java.io.OutputStream) (fos)), null);
				fos.close();
			}
			catch(IOException e)
			{
				
			}
		}
	}
	
	public void addDeath(EntityPlayer player)
	{
		File file = new File(saveDir, player.username + ".dat");
		NBTTagCompound tag = new NBTTagCompound();;
		int deaths = getDeathCount(player.username) + 1;
		tag.setInteger("deaths", deaths);
		
		deathCounter.put(player.username, deaths);
		sortRanking();
		
        try
        {
            CompressedStreamTools.writeCompressed(tag, new FileOutputStream(file));
        }
        catch(IOException ioexception)
        {
            console("Failed to save death count for " + player.username);
        }

	}
	
	public boolean clearDeath(String s)
	{
		if(s == null)
		{
			File[] files = saveDir.listFiles();
			for(File file : files)
			{
				file.delete();
			}
			deathCounter.clear();
			ranking.clear();
			return true;
		}
		else
		{
			File file = new File(saveDir, s + ".dat");
			if(file.exists())
			{
				file.delete();
				deathCounter.remove(s);
				sortRanking();
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	
	public int getDeathCount(String s)
	{
		try
		{
			return deathCounter.get(s);
		}
		catch(NullPointerException e)
		{
			return 0;
		}
	}
	
	public int getDisplayedRank(String s)
	{
		if(ranking.contains(s))
		{
			for(int i = 0; i < ranking.size(); i++)
			{
				if(ranking.get(i).equals(s))
				{
					int rank = i;
					int deaths = getDeathCount(s);
					while(i > 0 && getDeathCount(ranking.get(--i)) == deaths)
					{
						rank--;
					}
					return rank + 1;
				}
			}
		}
		return ranking.size() + 1;
	}
	
	@ForgeSubscribe
	public void onDeath(LivingDeathEvent event)
	{
		if(event.entityLiving instanceof EntityPlayer && FMLCommonHandler.instance().getEffectiveSide() == Side.SERVER && FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().getPlayerForUsername(((EntityPlayer)event.entityLiving).username) != null)
		{
			EntityPlayer player = (EntityPlayer)event.entityLiving;
			addDeath(player);
			if(message > 0)
			{
				if(message == 1)
				{
					player.addChatMessage("Deaths: " + getDeathCount(player.username) + " Rank: " + getDisplayedRank(player.username));
				}
				if(message == 2)
				{
					player.addChatMessage("You have died " + getDeathCount(player.username) + " times.");
					player.addChatMessage("You are ranked " + getDisplayedRank(player.username) + " on the server.");
				}
			}
		}
	}
	
	@ForgeSubscribe
	public void onChatEvent(ServerChatEvent event)
	{
		if("!dc".toLowerCase().startsWith(event.message.toLowerCase()) || "!deathcounter".toLowerCase().startsWith(event.message.toLowerCase()))
		{
			CommandDeathCounter.broadcastLeaderboard(event.username);
			event.setCanceled(true);
		}
	}
	
	public static void console(String s)
	{
		LoggerHelper.log(Level.INFO, s);
	}
}
